export const PARTNER = {
  LOOMIS_SAYLES: 'Loomis Sayles',
  HARRIS_ASSOCIATES: 'Harris Associates',
  THEMATICS: 'Thematics',
  DNCA: 'DNCA'
}