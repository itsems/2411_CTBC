<template>
  <GradientBackground :mobile-position="0" :desktop-position="0" />
  <div class="page-layout pt-[49px] lg:pt-0">
    <div class="pt-4 content" id="main-content">
      <a
        class="inline-block mb-2 focused-class-for-accessibility-focus text-main"
        href="#central-content"
        title="中央內容區(快速鍵Alt+C)"
        accesskey="C"
        id="central-content">
        :::
      </a>
      <div>
        <p class="mb-4 text-2xl text-main">
          淨值/配息資訊
        </p>
        <div
          class="grid gap-3 mb-6 sm:grid-cols-2 xl:grid-cols-4 lg:gap-6">
          <div class="relative">
            <RouterLink
              :to="{ name: ROUTE_NAME.accessibility.latestNav.name}"
              class="focused-class-for-accessibility-focus w-[calc(100%-2.25rem)] lg:w-[calc(100%-40px)] absolute z-0 flex justify-center py-3 -translate-y-1/2 bg-white rounded-2xl shadow-xl left-9 lg:left-[40px] top-1/2"
              title="最新淨值查詢">
              <div
                class="text-xl font-medium text-center text-font-color lg:pl-4">
                最新淨值查詢
              </div>
            </RouterLink>
            <div class="relative w-20">
              <img
                src="@/assets/images/acc/icon1.png"
                alt />
            </div>
          </div>
          <div class="relative">
            <RouterLink
              :to="{ name: ROUTE_NAME.accessibility.yield.name }"
              class="focused-class-for-accessibility-focus w-[calc(100%-2.25rem)] lg:w-[calc(100%-40px)] absolute z-0 flex justify-center py-3 -translate-y-1/2 bg-white rounded-2xl shadow-xl left-9 lg:left-[40px] top-1/2"
              title="基金配息">
              <div
                class="text-xl font-medium text-center text-font-color lg:pl-4">
                基金配息
              </div>
            </RouterLink>
            <div class="relative w-20">
              <img
                src="@/assets/images/acc/icon2.png"
                alt />
            </div>
          </div>
        </div>
        <div
          class="h-[2px] bg-[#d5d5d5] mb-6"></div>
        <p class="mb-4 text-2xl text-main">
          基金交易服務
        </p>
        <div
          class="grid gap-3 mb-6 sm:grid-cols-2 xl:grid-cols-4 lg:gap-6">
          <div class="relative">
            <a
              href="https://etrade.ctbcinvestments.com.tw/OpenOnline/"
              title="另開新視窗-線上開戶"
              target="_blank"
              class="focused-class-for-accessibility-focus w-[calc(100%-2.25rem)] lg:w-[calc(100%-40px)] absolute z-0 flex justify-center py-3 -translate-y-1/2 bg-white rounded-2xl shadow-xl left-9 lg:left-[40px] top-1/2"><div
                class="text-xl font-medium text-center text-font-color lg:pl-4">
                線上開戶
                <p class="text-xs">(另開新視窗)</p>
              </div></a>
            <div class="relative w-20">
              <img
                src="@/assets/images/acc/icon3.png"
                alt />
            </div>
          </div>
          <div class="relative">
            <a
              href="https://etrade.ctbcinvestments.com.tw/CTBC.EC/"
              title="另開新視窗-線上交易"
              target="_blank"
              class="focused-class-for-accessibility-focus w-[calc(100%-2.25rem)] lg:w-[calc(100%-40px)] absolute z-0 flex justify-center py-3 -translate-y-1/2 bg-white rounded-2xl shadow-xl left-9 lg:left-[40px] top-1/2"><div
                class="text-xl font-medium text-center text-font-color lg:pl-4">
                線上交易
                <p class="text-xs">(另開新視窗)</p>
              </div></a>
            <div class="relative w-20">
              <img
                src="@/assets/images/acc/icon4.png"
                alt />
            </div>
          </div>
          <div class="relative">
            <a
              href="https://etrade.ctbcinvestments.com.tw/ebill/"
              title="另開新視窗-ETF資料異動"
              target="_blank"
              class="focused-class-for-accessibility-focus w-[calc(100%-2.25rem)] lg:w-[calc(100%-40px)] absolute z-0 flex justify-center py-3 -translate-y-1/2 bg-white rounded-2xl shadow-xl left-9 lg:left-[40px] top-1/2"><div
                class="text-xl font-medium text-center text-font-color lg:pl-4">
                ETF資料異動
                <p class="text-xs">(另開新視窗)</p>
              </div></a>
            <div class="relative w-20">
              <img
                src="@/assets/images/acc/icon5.png"
                alt />
            </div>
          </div>
          <div class="relative">
            <RouterLink
              :to="{ name: ROUTE_NAME.accessibility.download.name}"
              class="focused-class-for-accessibility-focus w-[calc(100%-2.25rem)] lg:w-[calc(100%-40px)] absolute z-0 flex justify-center py-3 -translate-y-1/2 bg-white rounded-2xl shadow-xl left-9 lg:left-[40px] top-1/2"
              title="表單下載">
              <div
                class="text-xl font-medium text-center text-font-color lg:pl-4">
                表單下載
              </div>
            </RouterLink>
            <div class="relative w-20">
              <img
                src="@/assets/images/acc/icon6.png"
                alt />
            </div>
          </div>
        </div>
        <div
          class="h-[2px] bg-[#d5d5d5] mb-6"></div>
        <p class="mb-4 text-2xl text-main">
          更多服務
        </p>
        <div
          class="grid gap-3 mb-6 sm:grid-cols-2 xl:grid-cols-4 lg:gap-6">
          <div class="relative">
            <a
              href="https://www.ctbcinvestments.com/"
              title="另開新視窗-投信官網首頁"
              target="_blank"
              class="focused-class-for-accessibility-focus w-[calc(100%-2.25rem)] lg:w-[calc(100%-40px)] absolute z-0 flex justify-center py-3 -translate-y-1/2 bg-white rounded-2xl shadow-xl left-9 lg:left-[40px] top-1/2"><div
                class="text-xl font-medium text-center text-font-color lg:pl-4">
                投信官網首頁
                <p class="text-xs">(另開新視窗)</p>
              </div></a>
            <div class="relative w-20">
              <img
                src="@/assets/images/acc/icon7.png"
                alt />
            </div>
          </div>
          <div class="relative">
            <RouterLink
              :to="{ name: ROUTE_NAME.accessibility.env.name}"
              class="focused-class-for-accessibility-focus w-[calc(100%-2.25rem)] lg:w-[calc(100%-40px)] absolute z-0 flex justify-center py-3 -translate-y-1/2 bg-white rounded-2xl shadow-xl left-9 lg:left-[40px] top-1/2"
              title="無障礙設(措)施">
              <div
                class="text-xl font-medium text-center text-font-color lg:pl-4">
                無障礙設(措)施
              </div>
            </RouterLink>
            <div class="relative w-20">
              <img
                src="@/assets/images/acc/icon8.png"
                alt />
            </div>
          </div>
          <div class="relative">
            <RouterLink
              :to="{ name: ROUTE_NAME.accessibility.service.name}"
              class="focused-class-for-accessibility-focus w-[calc(100%-2.25rem)] lg:w-[calc(100%-40px)] absolute z-0 flex justify-center py-3 -translate-y-1/2 bg-white rounded-2xl shadow-xl left-9 lg:left-[40px] top-1/2"
              title="客戶服務">
              <div
                class="text-xl font-medium text-center text-font-color lg:pl-4">
                客戶服務
              </div>
            </RouterLink>
            
            <div class="relative w-20">
              <img
                src="@/assets/images/acc/icon9.png"
                alt />
            </div>
          </div>
        </div>
      </div>
    </div>
    <p class="mt-14">點選查看 <a target="_blank" class="underline hover:text-main hover:underline" href="https://www.sitca.org.tw/ROC/UserFriendly/main.aspx">
      中華民國證券投資信託暨顧問商業同業公會證券投資信託事業證券投資顧問事業金融友善服務準則條文及說明詳細條文</a></p>
  </div>
</template>
<script setup>
import { ROUTE_NAME } from '@/constants/page'

</script>
