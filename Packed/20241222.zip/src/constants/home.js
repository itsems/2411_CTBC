export const EVENT_TABS = {
  news: 'news',
  speech: 'speech',
  special: 'special'
}
export const FUND_MAIN_TABS = {
  onshore: 'onshore ',
  overseas: 'overseas'
}
export const FUND_SUB_TABS = {
  all: 'all',
  stock: 'stock',
  bond: 'bond',
  balance: 'balance',
  multi: 'multi',
  other: 'other'
}
export const VIDEO_TABS = {
  tuesday: 'tuesday',
  strategy: 'strategy'
}
